package Debugger;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Tester {
    public static void main(String[] args) {
        DateFormat dfor = new SimpleDateFormat("dd/MM/yy");
        Calendar obj = Calendar.getInstance();
        System.out.println(dfor.format(obj.getTime()));
    }
}
