package Interfaces;

public interface DataManagementSystem {
    public void addRecord(int userid);
    public void modifyRecord(int userid);
    public void deleteRecord(int userid);
    public void searchRecord();
    public void displayRecord();
}
