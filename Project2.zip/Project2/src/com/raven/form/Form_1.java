package com.raven.form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author RAVEN
 */
public class Form_1 extends javax.swing.JPanel {
    int userid;
    public void setExpense(int userid) {
        String id, date, description, amount;
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            Statement st = con.createStatement();
            if("".equals(expense_description.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Description is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if("".equals(expense_date.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Date is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else if("".equals(expense_amount.getText())) {
                JOptionPane.showMessageDialog(new JFrame(), "Amount is required!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            else {
                description = expense_description.getText().trim();
                date = expense_date.getText().trim();
                amount = expense_amount.getText().trim();
                
                String query = "INSERT INTO expenses(user_id, date, description, amount)" + "VALUES('"+userid+"' , '"+date+"' , '"+description+"' , '"+amount+"')";
                st.execute(query);
                expense_description.setText("");
                expense_date.setText("");
                expense_amount.setText("");
                showMessageDialog(null, "New account has been created successfully!");
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void listExpenseID(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT id FROM expenses WHERE user_id='"+userid+"'");
            ResultSet rs = ps.executeQuery();
            search_expense.removeAllItems();
            while(rs.next()) {
                search_expense.addItem(rs.getString(1));
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void getExpense() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String pid = search_expense.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM expenses WHERE id=?");
            ps.setString(1, pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()==true) {
                expense_date.setText(rs.getString(3));
                expense_description.setText(rs.getString(4));
                expense_amount.setText(rs.getString(5));   
            }
            else {
                JOptionPane.showMessageDialog(this, "No Record Found!");
            }
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    public void updateExpense(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String description = expense_description.getText();
        String date = expense_date.getText();
        String amount = expense_amount.getText();
        String id = search_expense.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("UPDATE expenses SET description=?, date=?, amount=? WHERE id=?");
            ps.setString(1, description);
            ps.setString(2, date);
            ps.setString(3, amount);
            ps.setString(4, id);
            int i = ps.executeUpdate();
            if(i==1) {
                JOptionPane.showMessageDialog(this, "Record updated successfully!");
                expense_description.setText("");
                expense_date.setText("");
                expense_amount.setText("");
                expense_description.requestFocus();
                listExpenseID(userid);
            } else {
                JOptionPane.showMessageDialog(this, "Record Update Unsuccessful!");
            }
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    public void deleteExpense(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String id = search_expense.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("DELETE FROM expenses WHERE id=?");
            ps.setString(1, id);
            int i = ps.executeUpdate();
            if(i==1) {
                JOptionPane.showMessageDialog(this, "Record Deleted successfully!");
                expense_description.setText("");
                expense_date.setText("");
                expense_amount.setText("");
                expense_description.requestFocus();
                listExpenseID(userid);
            } else {
                JOptionPane.showMessageDialog(this, "Record Delete Unsuccessful!");
            }
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    public void displayRecord(int userid) {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM expenses WHERE user_id='"+userid+"'");
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            int a = rss.getColumnCount();
            
            DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
            df.setRowCount(0);
            while(rs.next()) {
                Vector data = new Vector();
                for(int i = 1; i <= a; i++) {
                    data.add(rs.getString("id"));
                    data.add(rs.getString("date"));
                    data.add(rs.getString("description"));
                    data.add(rs.getString("amount"));
                }
                df.addRow(data);
            }
        } catch (Exception e) {
            System.out.println("Error: 1" + e);
        }
    }
    /**
     * Creates new form Form_1
     * @param userid
     */
    public Form_1(int userid) {
        this.userid = userid;
        initComponents();
        listExpenseID(userid);
        displayRecord(userid);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        expense_date = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        expense_amount = new javax.swing.JTextField();
        expense_update = new javax.swing.JButton();
        expense_delete = new javax.swing.JButton();
        expense_search = new javax.swing.JButton();
        expense_create = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new com.raven.swing.Table();
        expense_description = new javax.swing.JTextField();
        search_expense = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();

        setBackground(new java.awt.Color(242, 242, 242));

        jLabel1.setFont(new java.awt.Font("Roboto Slab", 1, 24)); // NOI18N
        jLabel1.setText("Manage Expenses");

        jLabel3.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Description");

        jLabel4.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Date");

        expense_date.setText("Enter Date");
        expense_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_dateActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Enter Amount");

        expense_amount.setText("Enter Amount");
        expense_amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_amountActionPerformed(evt);
            }
        });

        expense_update.setText("Update");
        expense_update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_updateActionPerformed(evt);
            }
        });

        expense_delete.setText("Delete");
        expense_delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_deleteActionPerformed(evt);
            }
        });

        expense_search.setText("Search");
        expense_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_searchActionPerformed(evt);
            }
        });

        expense_create.setText("Create");
        expense_create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_createActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Date", "Description", "Amount"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        expense_description.setText("Describe your Expense");
        expense_description.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_descriptionActionPerformed(evt);
            }
        });

        search_expense.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel6.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Expense ID");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 862, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(expense_description, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(expense_date, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(32, 32, 32)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(expense_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(expense_create, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(expense_update, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(expense_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(search_expense, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(expense_search, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(9, 9, 9)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(172, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(expense_date, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(expense_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(expense_description, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(60, 60, 60)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(search_expense)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(expense_update, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(expense_delete, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(expense_create, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(expense_search, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(68, 68, 68)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(166, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void expense_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_dateActionPerformed

    }//GEN-LAST:event_expense_dateActionPerformed

    private void expense_amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_expense_amountActionPerformed

    private void expense_updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_updateActionPerformed
        updateExpense(userid);
        listExpenseID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_expense_updateActionPerformed

    private void expense_deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_deleteActionPerformed
        deleteExpense(userid);
        listExpenseID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_expense_deleteActionPerformed

    private void expense_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_searchActionPerformed
        getExpense();
    }//GEN-LAST:event_expense_searchActionPerformed

    private void expense_createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_createActionPerformed
        setExpense(userid);
        listExpenseID(userid);
        displayRecord(userid);
    }//GEN-LAST:event_expense_createActionPerformed

    private void expense_descriptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_descriptionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_expense_descriptionActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField expense_amount;
    private javax.swing.JButton expense_create;
    private javax.swing.JTextField expense_date;
    private javax.swing.JButton expense_delete;
    private javax.swing.JTextField expense_description;
    private javax.swing.JButton expense_search;
    private javax.swing.JButton expense_update;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> search_expense;
    // End of variables declaration//GEN-END:variables
}
