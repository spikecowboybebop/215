package com.raven.form;

import com.raven.model.StatusType;
import com.raven.swing.ScrollBar;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author RAVEN
 */
public class Form_9 extends javax.swing.JPanel {
    public void listUserInfo() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT id FROM withdraw WHERE NOT status='Approved'");
            ResultSet rs = ps.executeQuery();
            search_expense.removeAllItems();
            while(rs.next()) {
                search_expense.addItem(rs.getString(1));
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    public void getUserInfo() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String pid = search_expense.getSelectedItem().toString();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM withdraw WHERE id=?");
            ps.setString(1, pid);
            ResultSet rs = ps.executeQuery();
            if(rs.next()==true) {
                user_id.setText(rs.getString("user_id"));
                withdraw_date.setText(rs.getString("date"));
                withdraw_amount.setText(rs.getString("amount"));   
            }
            
            String userid = user_id.getText();
            ps = con.prepareStatement("SELECT username FROM user WHERE id=?");
            ps.setString(1, userid);
            rs = ps.executeQuery();
            if(rs.next()==true) {
                username.setText(rs.getString("username"));  
            }
            
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    public void displayRecord() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("SELECT * FROM withdraw WHERE NOT status='Approved'");
            ResultSet rs = ps.executeQuery();
            ResultSetMetaData rss = rs.getMetaData();
            int a = rss.getColumnCount();
            DefaultTableModel df = (DefaultTableModel)jTable1.getModel();
            df.setRowCount(0);
            while(rs.next()) {
                Vector data = new Vector();
                for(int i = 1; i <= a; i++) {
                    data.add(rs.getString("id"));
                    data.add(rs.getString("date"));
                    data.add(rs.getString("amount"));
                    data.add(rs.getString("status"));
                }
                df.addRow(data);
            }
        } catch (Exception e) {
            System.out.println("Error: 1" + e);
        }
    }
    public void approve() {
        String url = "jdbc:MySQL://localhost/finance_management_system";
        String user = "root";
        String pass = "";
        String withdrawal_id = search_expense.getSelectedItem().toString();
        String userid = user_id.getText();
        String date = withdraw_date.getText();
        int balance = Integer.parseInt(withdraw_amount.getText()); 
        int originalBalance = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(url, user, pass);
            PreparedStatement ps = con.prepareStatement("UPDATE withdraw SET status=? WHERE id=?");
            ps.setString(1, "Approved");
            ps.setString(2, withdrawal_id);
            int i = ps.executeUpdate();
            if(i==1) { 
                ps = con.prepareStatement("SELECT balance FROM digital_wallet WHERE user_id='"+userid+"'");
                ResultSet rs = ps.executeQuery();
                if(rs.next()==true) {
                    originalBalance = rs.getInt("balance");
                    
                }
                ps = con.prepareStatement("UPDATE digital_wallet SET balance=? WHERE user_id='"+userid+"'");
                ps.setInt(1, (originalBalance - balance));
                ps.executeUpdate();
                
                Statement st = con.createStatement();
                String query = "INSERT INTO transaction_record(user_id, type, date, amount)" + "VALUES('"+userid+"' , 'Withdraw' , '"+date+"', '"+balance+"')";
                st.execute(query);
                
                JOptionPane.showMessageDialog(this, "Record updated successfully!");
                username.setText("");
                user_id.setText("");
                withdraw_amount.setText("");
                withdraw_date.setText("");
                username.requestFocus();
            } else {
                JOptionPane.showMessageDialog(this, "Record Update Unsuccessful!");
            }
        } catch(Exception e) {
            System.out.println("Eroor: " + e);
        }
    }
    /**
     * Creates new form Form_1
     * @param userid
     */
    public Form_9() {
        initComponents();
        listUserInfo();     
        displayRecord();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        username = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        user_id = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        withdraw_amount = new javax.swing.JTextField();
        expense_create = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        search_expense = new javax.swing.JComboBox<>();
        expense_search = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        withdraw_date = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new com.raven.swing.Table();

        setBackground(new java.awt.Color(242, 242, 242));

        jLabel2.setFont(new java.awt.Font("Roboto Slab", 1, 24)); // NOI18N
        jLabel2.setText("Approve Withdrawal Requests");

        jLabel3.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("User Name");

        username.setEditable(false);
        username.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                usernameActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("User ID");

        user_id.setEditable(false);
        user_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                user_idActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Amount");

        withdraw_amount.setEditable(false);
        withdraw_amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdraw_amountActionPerformed(evt);
            }
        });

        expense_create.setText("Approve");
        expense_create.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_createActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Withdrawal ID");

        search_expense.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        expense_search.setText("Search");
        expense_search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                expense_searchActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Roboto Slab", 1, 12)); // NOI18N
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Date");

        withdraw_date.setEditable(false);
        withdraw_date.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                withdraw_dateActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Withdrawal ID", "Date", "Amount", "Status"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(user_id, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(withdraw_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(withdraw_date, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(expense_create, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(search_expense, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(expense_search, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 862, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(190, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(withdraw_date, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(user_id, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(withdraw_amount, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(username, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(search_expense)
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(expense_search, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(expense_create, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(51, 51, 51)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(225, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void usernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_usernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_usernameActionPerformed

    private void user_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_user_idActionPerformed

    }//GEN-LAST:event_user_idActionPerformed

    private void withdraw_amountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdraw_amountActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_withdraw_amountActionPerformed

    private void expense_createActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_createActionPerformed
        approve();
        displayRecord();
    }//GEN-LAST:event_expense_createActionPerformed

    private void expense_searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expense_searchActionPerformed
        getUserInfo();
    }//GEN-LAST:event_expense_searchActionPerformed

    private void withdraw_dateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_withdraw_dateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_withdraw_dateActionPerformed

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton expense_create;
    private javax.swing.JButton expense_search;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JComboBox<String> search_expense;
    private javax.swing.JTextField user_id;
    private javax.swing.JTextField username;
    private javax.swing.JTextField withdraw_amount;
    private javax.swing.JTextField withdraw_date;
    // End of variables declaration//GEN-END:variables
}
